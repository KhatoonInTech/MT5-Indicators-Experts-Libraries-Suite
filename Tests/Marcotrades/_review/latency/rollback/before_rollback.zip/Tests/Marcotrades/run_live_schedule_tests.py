"""Verify that persistent symbol groups preserve the original scan ordering."""
from pathlib import Path
import re,subprocess
root=Path(__file__).resolve().parents[2]
text=(root/'Include/Custom/Marcotrades/marco_live_auto.mqh').read_text(encoding='utf-8-sig')
start=text.index('   string                  m_groupSymbols[];')
body=text.index('{',text.index('   void BuildSymbolGroups()',start));end=body+1;depth=1
while depth:
    depth+=(text[end]=='{')-(text[end]=='}');end+=1
source=text[start:end]
source=re.sub(r'\b(\w+)\s+(\w+)\[\];',r'std::vector<\1> \2;',source)
source=source.replace('m_instances[i].','m_instances[i]->')
mock=r'''
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include <random>
#include <cassert>
using string=std::string;
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
template<class T>void ArrayResize(std::vector<T>&v,int n){v.resize(n);}
struct Instance {string m_symbol;};
struct Scheduler {int m_total_instances;std::vector<Instance*> m_instances;
'''
cases=r'''
};
int main(){
 std::mt19937 rng(1927);int checks=0;
 for(int n=0;n<100;n++){
  Scheduler s;s.m_total_instances=n;std::vector<Instance> instances(n);
  for(int i=0;i<n;i++){instances[i].m_symbol="S"+std::to_string(rng()%11);s.m_instances.push_back(&instances[i]);}
  s.BuildSymbolGroups();
  for(int g=0;g<(int)s.m_groupSymbols.size();g++){
   std::vector<int>a,b;for(int i=0;i<n;i++)if(instances[i].m_symbol==s.m_groupSymbols[g])a.push_back(i);
   for(int i=s.m_groupFirst[g];i>=0;i=s.m_groupNext[i])b.push_back(i);
   assert(a==b);checks++;
  }
  if(!n)continue;
  for(int from=0;from<n;from++)for(int count:{1,15,n,n+15}){
   std::vector<string> old,newOrder;std::vector<bool> prepared(s.m_groupSymbols.size(),false);
   for(int k=0;k<count;k++){
    int index=(from+k)%n;string symbol=instances[index].m_symbol;
    if(std::find(old.begin(),old.end(),symbol)==old.end())old.push_back(symbol);
    int group=s.m_instanceGroup[index];assert(s.m_groupSymbols[group]==symbol);
    if(!prepared[group]){prepared[group]=true;newOrder.push_back(s.m_groupSymbols[group]);}
   }
   assert(old==newOrder);checks++;
  }
 }
 std::cout<<checks<<" symbol grouping and scan-order assertions passed\n";
}
'''
on_tick=text[text.index('   void              OnTick()'):text.index('   void              CheckDailyRollover()')]
assert on_tick.index('ManageStagedTP(m_trade)')<on_tick.index('ProcessLive(')<on_tick.index('CheckTPVicinityRejection(')
assert 'm_entryTF == ENTRY_TF_M1 ? m_total_instances : m_scanSpeed' in on_tick
assert 'm_current_scan_idx++;' in on_tick
out=root/'Tests/Marcotrades/_review/latency';out.mkdir(exist_ok=True)
cpp,exe=out/'live_schedule.cpp',out/'live_schedule.exe'
cpp.write_text(mock+source+cases)
subprocess.run([r'C:\MinGW\bin\g++.exe','-std=c++17','-O2',str(cpp),'-o',str(exe)],check=True)
subprocess.run([str(exe)],check=True)
