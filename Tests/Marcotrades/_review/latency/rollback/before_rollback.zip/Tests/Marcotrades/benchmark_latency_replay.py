"""Per-candle differential replay and CPU benchmark against a captured baseline.

Uses the existing offline production-code adapter. Does not attach to MT5.
Run after capturing baseline_sources.zip; --baseline can select an extracted tree.
"""
from pathlib import Path
import argparse, subprocess, sys, json, statistics, hashlib

root=Path(__file__).resolve().parents[2]
out=root/'Tests/Marcotrades/_review/latency'
parser=argparse.ArgumentParser()
parser.add_argument('--baseline',type=Path,default=out/'baseline')
parser.add_argument('--decision-stride',type=int,default=1)
parser.add_argument('--decision-fixture',default='')
parser.add_argument('--resume',action='store_true')
parser.add_argument('--repeats',type=int,default=3)
parser.add_argument('--reuse-builds',action='store_true')
args=parser.parse_args()
main=r'''
#include <chrono>
#include <iomanip>
void history(CTradeRejectionHistory &h,datetime now){
 std::cout<<" H "<<h.EventCount()<<" "<<h.ZoneCount();
 for(int e=0;e<h.EventCount();e++){SRejectionEvent v;if(h.EventAt(e,now,v))std::cout<<" E "<<v.name<<" "<<v.time<<" "<<v.available<<" "<<v.originTime<<" "<<v.originPrice<<" "<<v.linePrice;}
 for(int z=0;z<h.ZoneCount();z++){SRejectionLB v;h.ZoneAt(z,v);std::cout<<" Z "<<v.id<<" "<<v.bull<<" "<<v.low<<" "<<v.high<<" "<<v.created<<" "<<v.mitigation<<" "<<v.choch<<" "<<v.available<<" "<<v.until<<" "<<v.entryVetoed;}
}
int main(int argc,char**argv){
 std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 int decisionStride=argc>5?std::max(1,atoi(argv[5])):1;
 bool trace=std::string(argv[2])=="trace",merge=atoi(argv[3]),policy=atoi(argv[4]);
 CMarcoIndEntryFilter::Configure(IND_ENTRY_EITHER);
 Settings* settings=new Settings(.001,1,0,false,false,false,false,"Absolute");settings->draw=false;
 ZigZag* zz=newInstance(settings);CMarcoM1LBContext ctx;
 ctx.Init(true,true,2,1,true,merge,5,false,true,true,true,false,false,.1,policy);
 std::ifstream f(argv[1]);string line;std::getline(f,line);int i=0;
 double elapsed=0;std::cout<<std::setprecision(17);
 while(std::getline(f,line)){
  std::replace(line.begin(),line.end(),',',' ');std::istringstream s(line);
  datetime t;double o,h,l,c;long volume,real;int spread;s>>t>>o>>h>>l>>c>>volume>>spread>>real;
  auto start=std::chrono::steady_clock::now();
  zz->update(h,l,t,volume,i++,true,false);ctx.Update(t,o,h,l,c,zz,1.0);
  elapsed+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  if(trace){
   std::cout<<t<<" P "<<zz->pivots->Total();
   for(int p=0;p<zz->pivots->Total();p++){auto v=(Pivot*)zz->pivots->At(p);std::cout<<" "<<v->isHigh<<" "<<v->start->time<<" "<<v->start->price<<" "<<v->end->time<<" "<<v->end->price;}
   history(ctx.rejectionHistory,t+60);history(ctx.rawExitHistory,t+60);
   for(int z=0;z<ctx.ind->m_zones.Total();z++){
    auto v=(CInducementZone*)ctx.ind->m_zones.At(z);
    std::cout<<" I "<<v->id<<" "<<v->zoneLow<<" "<<v->zoneHigh<<" "<<v->createdTime<<" "<<v->touchCount<<" "<<v->isInducement<<" "<<v->qualifiedTime<<" "<<v->structureRejected<<" "<<v->isMitigated<<" "<<v->mitigationTime;
   }
   for(bool buy:{false,true}){
    string id;double low,high;std::cout<<" Q "<<ctx.indEntry.Inside(buy,c,t+60,low,high,id)<<" "<<id<<" "<<low<<" "<<high;
    if(i%decisionStride==0){auto q=ctx.rejectionHistory.OpposingChoch(buy,t-120,t,t,t+60,1,1);
    std::cout<<" "<<q.action<<" "<<q.reason<<" "<<q.opposingId<<" "<<q.eventTime;}
   }
   std::cout<<"\n";
  }
 }
 if(!trace)std::cout<<elapsed<<"\n";
 delete zz;
}
'''
executables={}
for label,tree in [('baseline',args.baseline),('optimized',root)]:
    if args.reuse_builds and (out/(label+'_replay.exe')).exists():
        executables[label]=out/(label+'_replay.exe');continue
    adapter=tree/'Tests/Marcotrades/replay_us30_context.py'
    env={'__file__':str(adapter)}
    exec(compile(adapter.read_text().split("main = r'''")[0],str(adapter),'exec'),env)
    cpp,exe=out/(label+'_replay.cpp'),out/(label+'_replay.exe')
    cpp.write_text(env['mock']+env['source']+main,encoding='utf-8')
    subprocess.run([r'C:\MinGW\bin\g++.exe','-std=c++17','-O2','-fmax-errors=3',str(cpp),'-o',str(exe)],check=True)
    executables[label]=exe
results=json.loads((out/'replay_benchmark.json').read_text()) if args.resume and (out/'replay_benchmark.json').exists() else []
for csv in sorted((root/'Tests/Marcotrades/_review').glob('us30*_m1.csv')):
    for merge,policy in [(0,0),(0,1),(1,0),(1,1)]:
        if args.resume and any(r['fixture']==csv.name and r['merge']==merge and r['entry_policy']==policy for r in results):continue
        stride=args.decision_stride if not args.decision_fixture or args.decision_fixture==csv.name else 1
        hashes={}
        for label,exe in executables.items():
            data=subprocess.check_output([str(exe),str(csv),'trace',str(merge),str(policy),str(stride)])
            hashes[label]=hashlib.sha256(data).hexdigest()
        assert hashes['baseline']==hashes['optimized'],(csv.name,merge,policy,hashes)
        timings={label:[] for label in executables}
        for repeat in range(args.repeats):
            for label,exe in executables.items():
                timings[label].append(float(subprocess.check_output([str(exe),str(csv),'bench',str(merge),str(policy)])))
        median={k:statistics.median(v) for k,v in timings.items() if v}
        result={'decision_stride':stride,'fixture':csv.name,'merge':merge,'entry_policy':policy,'identical_trace_sha256':hashes['baseline'],'median_ms':median,'samples_ms':timings,'speedup':median['baseline']/median['optimized'] if median else None}
        results.append(result)
        (out/'replay_benchmark.json').write_text(json.dumps(results,indent=2))
        print(csv.name,merge,policy,'identical trace',median,flush=True)
(out/'replay_benchmark.json').write_text(json.dumps(results,indent=2))
