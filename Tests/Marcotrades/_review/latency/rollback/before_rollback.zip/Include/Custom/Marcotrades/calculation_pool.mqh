#ifndef MARCO_CALCULATION_POOL_MQH
#define MARCO_CALCULATION_POOL_MQH
#include <Custom\Marcotrades\calculation_context.mqh>

// The pool deliberately expires at every event/pump boundary. Same-size history
// corrections therefore cannot leave persistent stale snapshots. Incomplete
// candles and failed/partial history loads are never cached.
class CMarcoCalculationPool
  {
private:
   CMarcoCalculationContext *items[];
   string barSymbols[];
   ENUM_TIMEFRAMES barTFs[];
   datetime barTimes[];
   datetime clock;
   bool active;
   int storedBars;
public:
   long loads,hits,columnBuilds;
   CMarcoCalculationPool() { active=false; clock=0; storedBars=0; loads=0; hits=0; columnBuilds=0; }
   ~CMarcoCalculationPool() { Clear(); }
   void Clear()
     {
      for(int i=0;i<ArraySize(items);i++) delete items[i];
      ArrayResize(items,0); ArrayResize(barSymbols,0); ArrayResize(barTFs,0); ArrayResize(barTimes,0);
      storedBars=0;
     }
   void Begin() { Clear(); clock=TimeCurrent(); active=true; }
   void End() { active=false; Clear(); }
   datetime CurrentBar(string symbol,ENUM_TIMEFRAMES tf)
     {
      if(!active) return iTime(symbol,tf,0);
      // Do not mask a new bar that arrives during a long processing callback.
      if(clock!=TimeCurrent()) { Clear(); clock=TimeCurrent(); }
      for(int i=0;i<ArraySize(barSymbols);i++)
         if(barSymbols[i]==symbol && barTFs[i]==tf) return barTimes[i];
      datetime value=iTime(symbol,tf,0);
      if(value<=0) return value;
      int n=ArraySize(barSymbols); ArrayResize(barSymbols,n+1); ArrayResize(barTFs,n+1); ArrayResize(barTimes,n+1);
      barSymbols[n]=symbol; barTFs[n]=tf; barTimes[n]=value;
      return value;
     }
   CMarcoCalculationContext *Find(string symbol,ENUM_TIMEFRAMES tf,datetime from,datetime to)
     {
      datetime current=CurrentBar(symbol,tf);
      if(!active || current<=0 || to>=current) return NULL;
      for(int i=0;i<ArraySize(items);i++)
         if(items[i].symbol==symbol && items[i].tf==tf && items[i].from==from && items[i].to==to)
           { hits++; return items[i]; }
      // A bounded working set; uncached requests still execute normally.
      if(storedBars>=131072) return NULL;
      CMarcoCalculationContext *context=new CMarcoCalculationContext(); loads++;
      int count=context.Load(symbol,tf,from,to);
      if(count<=0 || !SeriesInfoInteger(symbol,tf,SERIES_SYNCHRONIZED) ||
         count!=Bars(symbol,tf,from,to) || storedBars+count>131072)
        { delete context; return NULL; }
      int n=ArraySize(items); ArrayResize(items,n+1); items[n]=context; storedBars+=count;
      return context;
     }
   int Rates(string symbol,ENUM_TIMEFRAMES tf,datetime from,datetime to,MqlRates &result[])
     {
      CMarcoCalculationContext *context=Find(symbol,tf,from,to);
      if(context==NULL) return CopyRates(symbol,tf,from,to,result);
      ArrayResize(result,ArraySize(context.rates)); ArrayCopy(result,context.rates);
      return ArraySize(result);
     }
   int Columns(string symbol,ENUM_TIMEFRAMES tf,datetime from,datetime to,
               datetime &times[],double &opens[],double &highs[],double &lows[],double &closes[],long &volumes[])
     {
      CMarcoCalculationContext *context=Find(symbol,tf,from,to);
      bool temporary=context==NULL;
      if(temporary)
        {
         context=new CMarcoCalculationContext();
         int count=context.Load(symbol,tf,from,to);
         if(count<=0) { delete context; return count; }
        }
      if(!context.columnsReady) columnBuilds++;
      context.Columns();
      int n=ArraySize(context.rates);
      ArrayResize(times,n); ArrayResize(opens,n); ArrayResize(highs,n);
      ArrayResize(lows,n); ArrayResize(closes,n); ArrayResize(volumes,n);
      ArrayCopy(times,context.times); ArrayCopy(opens,context.opens); ArrayCopy(highs,context.highs);
      ArrayCopy(lows,context.lows); ArrayCopy(closes,context.closes); ArrayCopy(volumes,context.volumes);
      if(temporary) delete context;
      return n;
     }
  };
CMarcoCalculationPool g_marcoCalculations;
class CMarcoCalculationCycle
  {
public:
   CMarcoCalculationCycle() { g_marcoCalculations.Begin(); }
   ~CMarcoCalculationCycle() { g_marcoCalculations.End(); }
  };
#endif
