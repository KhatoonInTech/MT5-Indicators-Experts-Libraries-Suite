"""Production candle-pool tests; no terminal or broker access."""
from pathlib import Path
import re, subprocess

root=Path(__file__).resolve().parents[2]
out=root/'Tests/Marcotrades/_review/latency'
out.mkdir(exist_ok=True)
source='\n'.join((root/'Include/Custom/Marcotrades'/name).read_text() for name in ['calculation_context.mqh','calculation_pool.mqh'])
source=re.sub(r'^#include.*$','',source,flags=re.M)
source=re.sub(r'\b(\w+)\s+((?:\w+\[\]\s*,\s*)*\w+\[\]);',lambda m:'std::vector<'+m[1]+'> '+m[2].replace('[]','')+';',source)
source=source.replace('CMarcoCalculationContext *items[];','std::vector<CMarcoCalculationContext*> items;')
source=re.sub(r'\b(\w+)\s+&(\w+)\[\]',r'std::vector<\1> &\2',source)
source=source.replace('context.','context->')
source=re.sub(r'items\[([^]]+)\]\.',r'items[\1]->',source)
mock=r'''
#include <string>
#include <vector>
#include <iostream>
#include <cassert>
using string=std::string;using datetime=long long;using ENUM_TIMEFRAMES=int;
const int SERIES_SYNCHRONIZED=1;
struct MqlRates { datetime time;double open,high,low,close;long tick_volume;int spread;long real_volume; };
datetime now=600,current=600;int loads=0,itimes=0;bool sync=true,fail=false,partial=false;
std::vector<MqlRates> data={{60,1,3,0,2,10,2,0},{120,2,4,1,3,20,3,0}};
datetime TimeCurrent(){return now;}datetime iTime(string,int,int){itimes++;return current;}
int SeriesInfoInteger(string,int,int){return sync;}
int Bars(string,int,datetime first,datetime last){int n=0;for(auto r:data)if(r.time>=first&&r.time<=last)n++;return n;}
int CopyRates(string,int,datetime first,datetime last,std::vector<MqlRates>&v){loads++;v.clear();if(fail)return -1;for(auto r:data)if(r.time>=first&&r.time<=last)v.push_back(r);if(partial&&!v.empty())v.pop_back();return v.size();}
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
template<class T>void ArrayResize(std::vector<T>&v,int n){v.resize(n);}
template<class T>void ArrayCopy(std::vector<T>&a,const std::vector<T>&b){a=b;}
int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAILED "<<__LINE__<<": "<<#x<<"\n";return 1;}}while(0)
'''
cases=r'''
int main(){
 CMarcoCalculationPool p;std::vector<MqlRates>a,b;
 p.Begin();CHECK(p.Rates("A",1,60,180,a)==2);CHECK(p.Rates("A",1,60,180,b)==2);CHECK(loads==1);
 a[0].low=-100;CHECK(b[0].low==0); // consumer mutation cannot poison shared data
 std::vector<datetime>t;std::vector<double>o,h,l,c;std::vector<long>v;
 CHECK(p.Columns("A",1,60,180,t,o,h,l,c,v)==2);CHECK(loads==1&&p.columnBuilds==1);
 CHECK(t[1]==120&&o[1]==2&&h[1]==4&&l[1]==1&&c[1]==3&&v[1]==20);
 CHECK(p.Columns("A",1,60,180,t,o,h,l,c,v)==2);CHECK(p.columnBuilds==1);
 CHECK(p.Rates("B",1,60,180,b)==2);CHECK(loads==2);
 CHECK(p.Rates("A",2,60,180,b)==2);CHECK(loads==3);
 CHECK(p.Rates("A",1,120,180,b)==1);CHECK(b[0].time==120&&loads==4);
 CHECK(p.Rates("A",1,60,90,b)==1);CHECK(b[0].time==60&&loads==5); // earlier replay cutoff
 p.End();data[0].close=77;p.Begin();CHECK(p.Rates("A",1,60,180,b)==2);CHECK(b[0].close==77&&loads==6);
 now++;data[0].close=88;CHECK(p.Rates("A",1,60,180,b)==2);CHECK(b[0].close==88&&loads==7);
 // An incomplete candle must be re-read even within the same callback.
 data.push_back({600,3,5,2,4,40,2,0});int before=loads;
 CHECK(p.Rates("A",1,60,600,b)==3);data.back().close=99;CHECK(p.Rates("A",1,60,600,b)==3);
 CHECK(b.back().close==99&&loads==before+2);
 p.End();p.Begin();partial=true;CHECK(p.Rates("A",1,60,180,b)==1);partial=false;CHECK(p.Rates("A",1,60,180,b)==2);
 p.End();p.Begin();fail=true;CHECK(p.Rates("A",1,60,180,b)==-1);fail=false;CHECK(p.Rates("A",1,60,180,b)==2);
 p.End();p.Begin();sync=false;CHECK(p.Rates("A",1,60,180,b)==2);sync=true;data[0].close=111;CHECK(p.Rates("A",1,60,180,b)==2);CHECK(b[0].close==111);
 p.End();CHECK(p.Rates("A",1,60,180,b)==2);data[0].close=112;CHECK(p.Rates("A",1,60,180,b)==2);CHECK(b[0].close==112);
 // A second program owns a distinct pool, even for matching symbols/windows.
 CMarcoCalculationPool other;other.Begin();CHECK(other.Rates("A",1,60,180,b)==2);CHECK(other.loads==1);
 {CMarcoCalculationCycle cycle;CHECK(g_marcoCalculations.Rates("A",1,60,180,b)==2);}
 data[0].close=113;CHECK(g_marcoCalculations.Rates("A",1,60,180,b)==2);CHECK(b[0].close==113);
 std::cout<<checks<<" calculation-pool assertions passed\n";
}
'''
cpp,exe=out/'calculation_pool.cpp',out/'calculation_pool.exe'
cpp.write_text(mock+source+cases)
subprocess.run([r'C:\MinGW\bin\g++.exe','-std=c++17','-O2',str(cpp),'-o',str(exe)],check=True)
subprocess.run([str(exe)],check=True)
