#ifndef MARCO_CALCULATION_CONTEXT_MQH
#define MARCO_CALCULATION_CONTEXT_MQH

// Immutable candle snapshot for one program processing cycle. Consumers receive
// copies; neither simulation cursors nor per-setup trading state live here.
class CMarcoCalculationContext
  {
public:
   string symbol;
   ENUM_TIMEFRAMES tf;
   datetime from,to;
   MqlRates rates[];
   datetime times[];
   double opens[],highs[],lows[],closes[];
   long volumes[];
   bool columnsReady;
   CMarcoCalculationContext() { columnsReady=false; }
   int Load(string sym,ENUM_TIMEFRAMES period,datetime first,datetime last)
     {
      symbol=sym; tf=period; from=first; to=last;
      return CopyRates(sym,period,first,last,rates);
     }
   void Columns()
     {
      if(columnsReady) return;
      int n=ArraySize(rates);
      ArrayResize(times,n); ArrayResize(opens,n); ArrayResize(highs,n);
      ArrayResize(lows,n); ArrayResize(closes,n); ArrayResize(volumes,n);
      for(int i=0;i<n;i++)
        {
         times[i]=rates[i].time; opens[i]=rates[i].open; highs[i]=rates[i].high;
         lows[i]=rates[i].low; closes[i]=rates[i].close; volumes[i]=rates[i].tick_volume;
        }
      columnsReady=true;
     }
  };
#endif
