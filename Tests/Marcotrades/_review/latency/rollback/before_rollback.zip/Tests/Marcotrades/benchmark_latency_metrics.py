"""Collect per-candle timing and process peak memory for the offline replay.

Run benchmark_latency_replay.py first to generate baseline/optimized adapters.
These are host measurements, not MT5 order-execution or broker-fill timings.
"""
from pathlib import Path
import subprocess, ctypes, ctypes.wintypes as wt, json
root=Path(__file__).resolve().parents[2]
out=root/'Tests/Marcotrades/_review/latency'
class Counters(ctypes.Structure):
    _fields_=[('cb',wt.DWORD),('faults',wt.DWORD)]+[(name,ctypes.c_size_t) for name in ['peak_working_set','working_set','peak_paged','paged','peak_nonpaged','nonpaged','pagefile','peak_pagefile','private']]
get_memory=ctypes.windll.psapi.GetProcessMemoryInfo
get_memory.argtypes=[wt.HANDLE,ctypes.POINTER(Counters),wt.DWORD]
get_memory.restype=wt.BOOL
results={}
for label in ['baseline','optimized']:
    source=(out/(label+'_replay.cpp')).read_text(encoding='utf-8')
    source=source.replace('double elapsed=0;', 'std::vector<double> samples;double elapsed=0;')
    source=source.replace('elapsed+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();','double duration=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();elapsed+=duration;samples.push_back(duration);')
    source=source.replace('if(!trace)std::cout<<elapsed<<"\\n";', 'if(!trace){std::sort(samples.begin(),samples.end());std::cout<<elapsed<<" "<<samples[samples.size()/2]<<" "<<samples[(samples.size()-1)*95/100]<<" "<<samples.back()<<"\\n";}')
    cpp,exe=out/(label+'_metrics.cpp'),out/(label+'_metrics.exe')
    cpp.write_text(source,encoding='utf-8')
    subprocess.run([r'C:\MinGW\bin\g++.exe','-std=c++17','-O2','-fmax-errors=3',str(cpp),'-o',str(exe)],check=True)
    process=subprocess.Popen([str(exe),str(root/'Tests/Marcotrades/_review/us30_20261112_m1.csv'),'bench','0','0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stdout,stderr=process.communicate()
    if process.returncode:raise RuntimeError(stderr.decode(errors='replace'))
    counters=Counters();counters.cb=ctypes.sizeof(counters)
    measured=bool(get_memory(wt.HANDLE(int(process._handle)),ctypes.byref(counters),counters.cb))
    total,median,p95,worst=map(float,stdout.split())
    results[label]={'total_calculation_ms':total,'median_candle_ms':median,'p95_candle_ms':p95,'max_candle_ms':worst,'peak_process_working_set_bytes':counters.peak_working_set if measured else None}
    print(label,results[label],flush=True)
    (out/'latency_metrics.json').write_text(json.dumps(results,indent=2))
