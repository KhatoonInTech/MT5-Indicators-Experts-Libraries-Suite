"""Compare indexed production history against the frozen pre-optimization code."""
from pathlib import Path
import re, subprocess

root = Path(__file__).resolve().parents[2]
out = root / 'Tests/Marcotrades/_review/latency'
out.mkdir(exist_ok=True)
source = (root/'Include/Custom/Marcotrades/trade_rejection.mqh').read_text(encoding='utf-8-sig')
source = re.sub(r'^#include.*$', '', source, flags=re.M)
source = re.sub(r'\b(\w+)\s+(\w+)\[\];', r'std::vector<\1> \2;', source)
mock = (root/'Tests/Marcotrades/staged_tp_mocks.cpp').read_text() + r'''
#include <chrono>
#include <random>
using uint=unsigned int;
enum{PERIOD_CURRENT=0,PERIOD_M1=1,PERIOD_M2=2,TIME_DATE=1,TIME_SECONDS=2};
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
template<class T>void ArrayResize(std::vector<T>&v,int n){v.resize(n);}
string EnumToString(int x){return std::to_string(x);}
string TimeToString(datetime x,int){return std::to_string(x);}
template<class...T>void Print(T...){}
int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAILED "<<__LINE__<<": "<<#x<<"\n";std::exit(1);}}while(0)
'''
reference = (root/'Tests/Marcotrades/latency_reference_history.cpp').read_text()
cases = r'''
bool equal(const SRejectionEvent&a,const SRejectionEvent&b){return a.name==b.name&&a.time==b.time&&a.available==b.available&&a.until==b.until&&a.originTime==b.originTime&&a.originPrice==b.originPrice&&a.linePrice==b.linePrice;}
bool equal(const SRejectionLB&a,const SRejectionLB&b){return a.id==b.id&&a.bull==b.bull&&a.seen==b.seen&&a.entryVetoed==b.entryVetoed&&a.low==b.low&&a.high==b.high&&a.created==b.created&&a.mitigation==b.mitigation&&a.choch==b.choch&&a.available==b.available&&a.until==b.until;}
template<class H>double benchmark(){
 H h;for(int i=1;i<=4000;i++)h.Observe(i%2?"BR-BOS":"BL-BOS",i*60,i*60+60,i*60-60,100);
 auto start=std::chrono::steady_clock::now();long long sink=0;
 for(int i=0;i<10000;i++){SRejectionEvent e;if(h.Latest(240060,e))sink+=e.time;}
 CHECK(sink==2400000000LL);
 return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
}
int main(){
 CTradeRejectionHistory fast;CReferenceRejectionHistory old;
 std::mt19937 rng(8171);string names[]={"BL-CHoCH","BR-CHoCH","BL-BOS","BR-BOS","BSL-Swept","SSL-Swept"};
 for(int step=1;step<=600;step++){
  datetime now=1000+step*60;
  for(int e=0;e<3;e++){
   datetime when=1000+(rng()%step)*60;string name=names[rng()%6];datetime origin=when-60;double price=90+rng()%30;
   fast.Observe(name,when,now,origin,price,99);old.Observe(name,when,now,origin,price,99);
  }
  fast.BeginZones();old.BeginZones();
  for(int z=0;z<20;z++)if(rng()%5){
   string id="zone"+std::to_string(z);bool bull=z%2;double low=90+z/2,high=low+10+(rng()%2);datetime mitigation=rng()%7?0:now-60,choch=1000+(rng()%step)*60;
   fast.Zone(id,bull,low,high,900,mitigation,choch,now,z%3==0);old.Zone(id,bull,low,high,900,mitigation,choch,now,z%3==0);
  }
  fast.EndZones(now);old.EndZones(now);
  CHECK(fast.EventCount()==old.EventCount());CHECK(fast.ZoneCount()==old.ZoneCount());
  for(int q=0;q<8;q++){
   datetime at=q==0?now:1000+(rng()%(step+10))*60;
   SRejectionEvent a,b;bool x=fast.Latest(at,a),y=old.Latest(at,b);CHECK(x==y);if(x)CHECK(equal(a,b));
   for(bool buy:{false,true}){
    string ia,ib;CHECK(fast.IncomingLeg(buy,now-120,100,at,1,1,ia)==old.IncomingLeg(buy,now-120,100,at,1,1,ib));CHECK(ia==ib);
    auto ra=fast.OpposingChoch(buy,now-120,now,now-60,at,1,1),rb=old.OpposingChoch(buy,now-120,now,now-60,at,1,1);
    CHECK(ra.action==rb.action&&ra.reason==rb.reason&&ra.sourceTF==rb.sourceTF&&ra.opposingId==rb.opposingId&&ra.eventTime==rb.eventTime);
   }
  }
  for(int i=0;i<fast.ZoneCount();i++){SRejectionLB a,b;CHECK(fast.ZoneAt(i,a)&&old.ZoneAt(i,b));CHECK(equal(a,b));}
  if(step%200==0){fast.Reset();old.Reset();}
 }
 double baseline=benchmark<CReferenceRejectionHistory>(),indexed=benchmark<CTradeRejectionHistory>();
 std::cout<<checks<<" differential history assertions passed\n";
 std::cout<<"Latest lookup microbenchmark: baseline_ms="<<baseline<<" indexed_ms="<<indexed<<"\n";
}
'''
cpp, exe = out/'history_parity.cpp', out/'history_parity.exe'
cpp.write_text(mock+source+reference+cases, encoding='utf-8')
subprocess.run([r'C:\MinGW\bin\g++.exe','-std=c++17','-O2',str(cpp),'-o',str(exe)],check=True)
subprocess.run([str(exe)],check=True)
